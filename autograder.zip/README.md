# cs12x-exam2-autograder
gradescope autograder for csce 120/121 exam 2

## packing for upload to gradescope
zip run_autograder setup.sh ssh_config deploy_key

## manual override of version
submit file VERSION with student code.  VERSION should contain a single line: the name of the class to use. 