#include <iostream>
#include <string>
#include <limits>
#include "string_calculator.h"

using std::cout, std::endl, std::cin;
using std::string;

int main() {
    cout << "String Calculator" << endl;
    cout << "\"q\" or \"quit\" or ctrl+d to exit" << endl;
    
    // TODO(student): implement the UI
    cout << add("-1", "-9") << "= -10"<< endl;
   /*
    //cout <<  add("4566783", "434") << endl;
//     cout << add("0", "0") << "= 0" << endl;
// cout << add("0", "1") << "= 1"<< endl;
// cout << add("0", "2") << "= 2"<< endl;
// cout << add("0", "3") << "= 3"<< endl;
// cout << add("0", "4") << "= 4"<< endl;
// cout << add("0", "5") << "= 5"<< endl;
// cout << add("0", "6") << "= 6"<< endl;
// cout << add("0", "7") << "= 7"<< endl;
// cout << add("0", "8") << "= 8"<< endl;
// cout << add("0", "9") << "= 9"<< endl;
// cout << add("1", "1") << "= 2"<< endl;
// cout << add("1", "2") << "= 3"<< endl;
// cout << add("1", "3") << "= 4"<< endl;
// cout << add("1", "4") << "= 5"<< endl;
// cout << add("1", "5") << "= 6"<< endl;
// cout << add("1", "6") << "= 7"<< endl;
// cout << add("1", "7") << "= 8"<< endl;
// cout << add("1", "8") << "= 9"<< endl;
cout << add("1", "9") << "= 10"<< endl;
// cout << add("2", "2") << "= 4"<< endl;
// cout << add("2", "3") << "= 5"<< endl;
// cout << add("2", "4") << "= 6"<< endl;
// cout << add("2", "5") << "= 7"<< endl;
// cout << add("2", "6") << "= 8"<< endl;
// cout << add("2", "7") << "= 9"<< endl;
cout << add("2", "8") << "= 10"<< endl;
cout << add("2", "9") << "= 11"<< endl;
// cout << add("3", "3") << "= 6"<< endl;
// cout << add("3", "4") << "= 7"<< endl;
// cout << add("3", "5") << "= 8"<< endl;
// cout << add("3", "6") << "= 9"<< endl;
cout << add("3", "7") << "= 10"<< endl;
cout << add("3", "8") << "= 11"<< endl;
cout << add("3", "9") << "= 12"<< endl;
// cout << add("4", "4") << "= 8"<< endl;
// cout << add("4", "5") << "= 9"<< endl;
cout << add("4", "6") << "= 10"<< endl;
cout << add("4", "7") << "= 11"<< endl;
cout << add("4", "8") << "= 12"<< endl;
cout << add("4", "9") << "= 13"<< endl;
cout << add("5", "5") << "= 10"<< endl;
cout << add("5", "6") << "= 11"<< endl;
cout << add("5", "7") << "= 12"<< endl;
cout << add("5", "8") << "= 13"<< endl;
cout << add("5", "9") << "= 14"<< endl;
cout << add("6", "6") << "= 12"<< endl;
cout << add("6", "7") << "= 13"<< endl;
cout << add("6", "8") << "= 14"<< endl;
cout << add("6", "9") << "= 15"<< endl;
cout << add("7", "7") << "= 14"<< endl;
cout << add("7", "8") << "= 15"<< endl;
cout << add("7", "9") << "= 16"<< endl;
cout << add("8", "8") << "= 16"<< endl;
cout << add("8", "9") << "= 17"<< endl;
cout << add("9", "9") << "= 18"<< endl;
cout << add("99", "1") << "= 100"<< endl;
cout << add("1", "999") << "= 1000"<< endl;
//cout << add("867", "5309") << "= 6176"<< endl;
//cout << add("123", "456") << "= 579"<< endl;
cout << add("7654", "2346") << "= 10000"<< endl;
cout << add("56678", "66778") << "= 123456"<< endl;
cout << add("1234567890", "9876543210") << "= 11111111100"<< endl;
//cout << add("0", "125416") << "= 125416"<< endl;
*/
}

